import './compost/components/compost-knob.js';
import './compost/components/compost-piano.js';

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const mappingPulseTimers = new WeakMap();
const mappingPrefix = 'param-indication:';
// Post the underlying ArrayBuffer: browser hosts reject ArrayBuffer views,
// and native webview bridges accept either.
const send = (text) => window.parent.postMessage(encoder.encode(text).buffer, '*');

function setMappingIndication(parameterID, hasMapping, label) {
  const control = document.querySelector(`[parameter-id="${parameterID}"]`);
  if (!control) return;

  const previousTimer = mappingPulseTimers.get(control);
  if (previousTimer) clearTimeout(previousTimer);
  mappingPulseTimers.delete(control);

  if (!hasMapping) {
    control.removeAttribute('data-midi-map-mode');
    control.removeAttribute('data-midi-map-label');
    control.removeAttribute('data-midi-map-target-active');
    control.removeAttribute('data-midi-map-pulse');
    control.style.removeProperty('--midi-map-label');
    return;
  }

  control.setAttribute('data-midi-map-mode', '');
  control.setAttribute('data-midi-map-label', '');
  control.style.setProperty('--midi-map-label', JSON.stringify(label));
  control.setAttribute('data-midi-map-target-active', '');
  control.removeAttribute('data-midi-map-pulse');
  requestAnimationFrame(() => control.setAttribute('data-midi-map-pulse', ''));

  const timer = setTimeout(() => {
    control.removeAttribute('data-midi-map-target-active');
    control.removeAttribute('data-midi-map-pulse');
    mappingPulseTimers.delete(control);
  }, 700);
  mappingPulseTimers.set(control, timer);
}

addEventListener('parameter-begin', ({ detail }) => send(`begin:${detail.parameterID}`));
addEventListener('parameter-edit', ({ detail }) => send(`value:${detail.parameterID}:${detail.value}`));
addEventListener('parameter-end', ({ detail }) => send(`end:${detail.parameterID}`));
addEventListener('note-down', ({ detail }) => send(`note-on:${detail.note}:0.8`));
addEventListener('note-up', ({ detail }) => send(`note-off:${detail.note}`));

addEventListener('message', ({ data }) => {
  const text = decoder.decode(data);
  if (text.startsWith(mappingPrefix)) {
    const firstSeparator = text.indexOf(':', mappingPrefix.length);
    const secondSeparator = text.indexOf(':', firstSeparator + 1);
    if (firstSeparator < 0 || secondSeparator < 0) return;
    const parameterID = text.slice(mappingPrefix.length, firstSeparator);
    const hasMapping = text.slice(firstSeparator + 1, secondSeparator) === '1';
    setMappingIndication(parameterID, hasMapping, text.slice(secondSeparator + 1));
    return;
  }
  if (!text.startsWith('values:')) return;
  for (const pair of text.slice(7).split(';')) {
    const [id, value] = pair.split('=');
    const control = document.querySelector(`[parameter-id="${id}"]`);
    if (control) control.value = Number(value);
  }
});

send('ready');
