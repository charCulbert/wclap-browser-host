import './compost/components/compost-knob.js';
import './compost/components/compost-piano.js';

const encoder = new TextEncoder();
const decoder = new TextDecoder();
// Post the underlying ArrayBuffer: browser hosts reject ArrayBuffer views,
// and native webview bridges accept either.
const send = (text) => window.parent.postMessage(encoder.encode(text).buffer, '*');

addEventListener('parameter-begin', ({ detail }) => send(`begin:${detail.parameterID}`));
addEventListener('parameter-edit', ({ detail }) => send(`value:${detail.parameterID}:${detail.value}`));
addEventListener('parameter-end', ({ detail }) => send(`end:${detail.parameterID}`));
addEventListener('note-down', ({ detail }) => send(`note-on:${detail.note}:0.8`));
addEventListener('note-up', ({ detail }) => send(`note-off:${detail.note}`));

addEventListener('message', ({ data }) => {
  const text = decoder.decode(data);
  if (!text.startsWith('values:')) return;
  for (const pair of text.slice(7).split(';')) {
    const [id, value] = pair.split('=');
    const control = document.querySelector(`[parameter-id="${id}"]`);
    if (control) control.value = Number(value);
  }
});

send('ready');
